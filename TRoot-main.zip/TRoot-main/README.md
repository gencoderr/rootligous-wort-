# TRoot
This is a simple proot bassed root script for your termux.

# About
If you don't have a rooted andriod for that purpose this script can help you for getting root acess of your Termux.

# $upport 

Instagram=>@true.living
